$(document).ready(function()
{
    $(window).scroll(function(){
        if(this.scrollY>20)
        {
 
            $('.navbar').addClass("sticky");
        }
        else
        {
            $('.navbar').removeClass("sticky");

        }
    });


    $(document).ready(function() {
        $('.menu_btn').click(function() {
            $('.menu').toggleClass("active");
            $('.menu_btn i').toggleClass("active");
        });
    });
});


