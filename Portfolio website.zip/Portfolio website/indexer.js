const http = require('http');
const fs = require('fs');
 
const hostname = '127.0.0.1';
const port = 5000;

let index = fs.readFileSync('./index.html');
let adminportal = fs.readFileSync('./adminportal.html');


fs.readFile('./index.html', 'utf8', (err, data) => {
  if (err) {
    console.error('Error reading index.html:', err);
    return;
  }


  const server = http.createServer((req, res) => {
    console.log(req.url);
    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/html');

    if (req.url == '/adminportal') {
      res.end(adminportal);
    } else {
      res.end(index);
    }
  });

  server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
  });
});