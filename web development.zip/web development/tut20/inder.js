

let mode  = require("./mode");
console.log(mode);
console.log(mode.avg([4,3]));
console.log(mode.Name);
console.log(mode.Repo);
console.log("index ")

