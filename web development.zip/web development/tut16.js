
const fs = require("fs");
let text = fs.readFile("basiq.txt" , "utf-8" , (err , data)=>{
    console.log(err , data);
});
console.log("Calling......");

