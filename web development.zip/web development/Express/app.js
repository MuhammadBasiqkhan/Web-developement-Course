const express = require("express");
const path = require("path");
const app = express();
const port = 80;

app.use('/static' , express.static('static'));
app.set('view engine', 'pug')
app.set('views', path.join(__dirname,'views'));

app.get("/index" , (req , res)=>{

    const content = "Muhammad Basiq Khan is that person who work for entire universe"
    const params= { 'tittle': 'My first pug documant' , 'content' : content};
    res.status(300).render('index.pug' , params);//, { title: 'Hey Muhammad Basiq khan', message: 'Hello there! is there weher you are ' });

});










// app.get("/" , (req , res)=>{

//     res.send("This is home Page express App of Muhammad basiq Khan");

// });

// app.get("/about" , (req , res)=>{

//     res.status(300).send("This is About page express App of Muhammad basiq Khan");

// });

// app.get("/contact" , (req , res)=>{

//     res.send("This is Contact page express App of Muhammad basiq Khan");

// });

// app.get("/services" , (req , res)=>{

//     res.send("This is Services page express App of Muhammad basiq Khan"); 

// });
// app.post("/services" , (req , res)=>{

//     res.send("This is post Services page express App of Muhammad basiq Khan"); 

// });
// app.put("/services" , (req , res)=>{

//     res.send("This is put Services page express App of Muhammad basiq Khan"); 

// });

app.listen(port , ()=>{
    console.log(`Server started successfully on port ${port}`)
})

