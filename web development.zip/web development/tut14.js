const http = require('http');
 
const hostname = '127.0.0.1';
const port = 3000;
 
const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/html');
  // res.end('Hello World this is Muhammad Basiq Khan');
  res.end(`<!DOCTYPE html>
  <html lang="en">
  
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Document</title>
  </head>
  <style>
      #btn{
          padding: 10px 14px;
          color: aliceblue;
          background-color: rgb(55, 55, 191);
          border-radius: 8px;
          border: 2px solid black;
  
      }
  
      #btn:hover{
          transition: 0.3s ease-in;
          background-color: aliceblue;
          border-color: lightblue;
          color:  rgb(55, 55, 191);
          
      }
  
      #btn:active{
          scale: 0.9;
          transition: 0.3s ease-in;
          background-color: aliceblue;
          border-color: lightblue;
          color:  rgb(55, 55, 191);
          
      }
  
    
  </style>
  <body>
  
      <div class="container">
          <h1>This is The main data</h1>
          <p id="paradata">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorum et, est maxime laboriosam non dolores
              blanditiis? Nostrum doloribus iusto quod at earum eius aliquid, repudiandae reprehenderit impedit quae dicta
              quasi minus eligendi, magni a? Perspiciatis, nostrum! Repellendus, animi quasi. Ratione blanditiis quisquam
              ducimus! Vel, deserunt. Sunt dolorum nulla pariatur et nostrum id placeat molestiae delectus dolores quaerat
              quod repellat tenetur eius totam ut magni modi, nesciunt, rem eum itaque, minima reiciendis. Quibusdam
              explicabo at quo aliquid laboriosam autem doloremque, ab deserunt perferendis temporibus consectetur facere,
              voluptatem beatae eum voluptate omnis? Amet delectus vitae fugiat commodi quis quidem facilis nisi. Id,
              officiis, quasi aperiam, rerum delectus deleniti eligendi tempore quis quisquam reiciendis explicabo
              reprehenderit eaque labore quae iste recusandae aliquid voluptas esse doloribus enim unde laboriosam nulla.
              Minima debitis reiciendis nisi iste optio perspiciatis maxime laboriosam soluta labore! Necessitatibus quos
              quas dignissimos ducimus corporis hic odio, alias ut architecto reiciendis minima obcaecati aliquam?
              Repellat quis, aut beatae dolorum ut repudiandae quas, quia maxime vero porro accusamus tempore doloremque
              qui impedit quod cupiditate? Labore libero consequuntur quae eveniet impedit ut, iure qui quasi debitis
              quaerat, ea assumenda temporibus cumque ipsum recusandae blanditiis pariatur atque. Perferendis, debitis
              est? Ipsam rerum rem aspernatur maiores?</p>
  
              <button id="btn" onclick="togglehide()" onmouseover="">Show/hide</button>
      </div>

      <p id="para"> </p>
  
      <script>
          // event listenning
          function togglehide(){
              let btn = document.getElementById('btn');
              let paradat = document.getElementById('paradata');
              paradat.addEventListener('mouseover' , function run(){
              
                  paradat.style.textAlign='center';
                  paradat.style.color='red';
                  paradat.style.backgroundColor='aliceblue';
                  paradat.style.width='50%';
                  paradat.style.letterSpacing='1px';
                  paradat.style.border='2px solid black';
                  paradat.style.borderRadius='8px';
                  paradat.style.padding='6px 4px';
                
                
              });
  
  
              if( paradat.style.display !='none'){
  
                  paradat.style.display='none';
              }
              else{
                  
                  paradat.style.display='block';
              }
          }
  
        
  
  
      </script>
  </body>
  
  </html>`);
});




 
server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
})