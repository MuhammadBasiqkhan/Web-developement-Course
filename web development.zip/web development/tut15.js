 
 
 
 const fs = require("fs");
 let text = fs.readFileSync("basiq.txt" , "utf-8");

 text = text.replace("Basiq" , "Muhammad");


 var array = ["Muhammad Basiq khan" , "Muhammmad Faiq Khan " , "Noamn irfan"]

console.log("The Content of file is ");
console.log(text);

console.log("creating new file.....")
fs.writeFileSync("here.txt", text);
fs.writeFileSync("here.txt", text +" Any thing happen to do what you want " + array);