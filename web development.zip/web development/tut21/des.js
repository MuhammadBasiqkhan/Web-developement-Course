
console.log("Muhsmmad Basiq Khan")
console.log("Muhsmmad Basiq Khan")
console.log("Muhsmmad Basiq Khan")
console.log("Muhsmmad Basiq Khan")